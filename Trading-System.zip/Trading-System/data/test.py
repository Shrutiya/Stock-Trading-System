from app import app
import unittest
import json
from flask import jsonify
import MySQLdb

class FlaskTestCase(unittest.TestCase):
	
	def login(self,user,pwd):
		tester=app.test_client(self)
		data={'username':user,'pwd': pwd}
		tester.post('/api/login',data=json.dumps(data),content_type='application/json',follow_redirects=True)	

	#Ensure that flask was set up correctly
	def test_index(self):
		tester=app.test_client(self)
		response=tester.get('/stocks/all')
		self.assertEqual(response.status_code,200)
	
	
	#ensure submission throttle works	
	def test_sub_throttle_status(self):
		tester=app.test_client(self)
		data="{'term':'A'}"
		response=tester.post('/check',data=data)
		self.assertEqual(response.status_code,200)

	def test_sub_throttle_check(self):
		tester=app.test_client(self)
		data="{'term':'A'}"
		response=tester.post('/check',data=data)
		self.assertIn(b'ABBV',response.data)

	#ensure about/description works correctly
	def test_about_des_status(self):
		tester=app.test_client(self)
		response=tester.get('/about/description')
		self.assertEqual(response.status_code,200)
		
	
	def test_about_des_check(self):
		tester=app.test_client(self)
		response=tester.get('/about/description')
		self.assertIn(b'Stocks Trading System',response.data)
	
	#ensure video is loaded properly
	def test_get_video(self):
		tester=app.test_client(self)
		response=tester.get('/about/video')
		self.assertEqual(response.status_code,200)
		self.assertEqual('video/mp4',response.content_type)

	#ensure we the predicted stocks of selected company correctly
	def test_predict_status(self):
		tester=app.test_client(self)
		data="{'symbol':'ABBV'}"
		response=tester.post('/stocks/detail',data=data)
		self.assertEqual(response.status_code,200)
		self.assertIn(b'actual',response.data)


	#ensure portfolio works correctly
	def test_portfolio_status(self):
		tester=app.test_client(self)
		self.login('michael','12345')
		response=tester.get('/user/portfolio')
		self.assertEqual(response.status_code,200)
		self.assertIn(b'transactions',response.data)
		

	#ensure get balance works
	def test_balance_check(self):
		tester=app.test_client(self)
		self.login('michael','12345')
		response=tester.get('/user/balance')
		self.assertEqual(response.status_code,200)
		self.assertEqual(b'"10000.00"\n',response.data)
	


	#ensure when user buys and he has enough money to buy the stock
	def test_buy_balance(self):
		
		tester=app.test_client(self)
		self.login('michael','12345')
		tester.get('/stocks/all')
		info={"symbol":"ABBV","username":"michael"}	
		response=tester.post('/stocks/buy',data=json.dumps(info),content_type='application/json')
		self.assertEqual(response.status_code,200)
		self.assertNotIn(b'No enough money',response.data)

	#ensure when user buys and he does not have enough balance to buy the stock
	def test_buy_no_balance(self):
		tester=app.test_client(self)
		self.login('john','12345')
		tester.get('/stocks/all')
		info={"symbol":"ABBV","username":"john"}	
		response=tester.post('/stocks/buy',data=json.dumps(info),content_type='application/json')
		self.assertEqual(response.status_code,200)
		self.assertIn(b'No enough money',response.data)
	
	
	#ensure sell stocks works when the stock is available in his account
	def test_sell_exist(self):
		tester=app.test_client(self)
		self.login('michael','12345')
		tester.get('/stocks/all')
		info={"symbol":"ABBV","username":"michael"}	
		response=tester.post('/stocks/sell',data=json.dumps(info),content_type='application/json')
		self.assertEqual(response.status_code,200)
		self.assertNotIn(b'Null',response.data)

	#ensure sell stocks gives null when the stock is not available in his account
	def test_sell_not_exist(self):
		tester=app.test_client(self)
		self.login('michael','12345')
		tester.get('/stocks/all')
		info={"symbol":"AMG","username":"michael"}	
		response=tester.post('/stocks/sell',data=json.dumps(info),content_type='application/json')
		self.assertEqual(response.status_code,200)
		self.assertIn(b'Null',response.data)

	
if __name__ == '__main__':
	unittest.main()
from selenium import webdriver  
import time  
from webdriver_manager.chrome import ChromeDriverManager
import unittest

#from selenium.webdriver.common.keys import Keys
class FlaskTestCase(unittest.TestCase):
	
	def test_a_no_user(self):
		
		#ensure no user is there in the beginning
			user_name=driver.find_element_by_name("logged_user").text[6:]
			user_balance=driver.find_element_by_name("logged_money").text[6:]

			self.assertEqual('',user_name)


	def test_b_buy_disable(self):

		#ensure no user is there in the beginning
		
			user_name=driver.find_element_by_name("logged_user").text[6:]
			user_balance=driver.find_element_by_name("logged_money").text[6:]

			if(not user_name):
				driver.find_element_by_name("buy").click()
				buy_button=driver.find_element_by_name("buy").is_enabled()
				self.assertEqual(False,buy_button)


	def test_c_sell_disable(self):
		#ensure no user is there in the beginning
		
			user_name=driver.find_element_by_name("logged_user").text[6:]
			user_balance=driver.find_element_by_name("logged_money").text[6:]

			if(not user_name):
				driver.find_element_by_name("sell").click()
				sell_button=driver.find_element_by_name("sell").is_enabled()
				self.assertEqual(False,sell_button)

	def test_d_user(self):
		#ensure login works 
		
			driver.find_element_by_name("login").click()
			time.sleep(5)
			driver.find_element_by_name("username").send_keys("shru")
			time.sleep(3)
			driver.find_element_by_name("password").send_keys("12345")
			time.sleep(3)
			driver.find_element_by_name("submit_login").click()
			time.sleep(100)

			user_name=driver.find_element_by_name("logged_user").text[6:]
			user_balance=driver.find_element_by_name("logged_money").text[6:]

			self.assertEqual("shru",user_name)

	def test_e_user_buy(self):
		  
		
			user_name=driver.find_element_by_name("logged_user").text[6:]
			user_balance1=driver.find_element_by_name("logged_money").text[6:]

			
			driver.find_element_by_name("buy").click()
			time.sleep(2)
			user_balance2=driver.find_element_by_name("logged_money").text[6:]

			self.assertGreater(user_balance1,user_balance2)

	def test_f_user_sell(self):
		
			user_name=driver.find_element_by_name("logged_user").text[6:]
			user_balance1=driver.find_element_by_name("logged_money").text[6:]

			
			driver.find_element_by_name("sell").click()
			time.sleep(2)
			user_balance2=driver.find_element_by_name("logged_money").text[6:]

			self.assertGreater(user_balance2,user_balance1)

	def test_g_graph(self):
		
			driver.find_element_by_name("detail").click()
			time.sleep(10)
			graph_element=driver.find_element_by_name("graph").get_attribute('innerHTML')
			self.assertTrue(graph_element)
			
	def test_h_profile(self):

			driver.find_element_by_name("profile").click()
			time.sleep(2)
			logs=driver.find_element_by_name("heading").get_attribute('innerText')
			self.assertIn('Transaction logs of shru',logs)

	def test_i_about(self):
		
			driver.find_element_by_name("about").click()
			time.sleep(5)
			video_element=driver.find_element_by_name("video").get_attribute('innerHTML')
			self.assertTrue(video_element)

	def test_j_check(self):

			driver.find_element_by_name("check").click()
			time.sleep(5)
			driver.find_element_by_name("search").send_keys('A')
			time.sleep(3)
			result_element=driver.find_element_by_class_name("fooditem").get_attribute('innerText')[0]
			self.assertEqual('A',result_element)



if __name__ == '__main__':
	print("sample test case started")  
	#driver = webdriver.Chrome(ChromeDriverManager().install())
	driver = webdriver.Chrome(r"C:\\Users\\prathiksha\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe")  
	#driver=webdriver.firefox()  
	#driver=webdriver.ie()  
	#maximize the window size  
	driver.maximize_window()  
	#navigate to the url  
	driver.get("C:\\Users\\prathiksha\\Downloads\\Trading-System\\views\\index.html")  
	time.sleep(100)
	unittest.main()
	driver.close()